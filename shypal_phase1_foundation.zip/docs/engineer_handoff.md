# Engineer Handoff - Native Work Items

These are required manual tasks to complete after Phase 1 scaffold:

1. Implement native iOS MultipeerConnectivity plugin (swift) exposing method channel APIs in mobile/native_plugins.
2. Implement native Android Nearby/Wi-Fi Direct plugin (kotlin).
3. Replace JS crypto with native libsodium or libsignal bindings and perform a third-party crypto audit.
4. Conduct device matrix field tests and tune scanning/ad intervals for battery and reliability.
5. Implement background handling and App Store permission rationales.
