# Threat Model (Phase 1)

- Simulated mode does not protect against real BLE fingerprinting. Production must use rotating ephemeral IDs.
- Phase 1 crypto is prototyping-level. Do not claim production security.
- Manual native implementation and security audit required before public release.
