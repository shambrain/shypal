# Device Test Matrix (Phase 1)

iOS:
- iPhone 14 Pro (iOS 17)
- iPhone 12 (iOS 16)
- iPhone SE (iOS 15)

Android:
- Pixel 7 (Android 14)
- Samsung Galaxy S23 (One UI latest)
- Xiaomi Redmi Note (MIUI)
- OnePlus Nord
