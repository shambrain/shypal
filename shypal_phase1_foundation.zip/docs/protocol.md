# ShyPal Protocol (Phase 1 - Simulated)

This document describes the Phase 1 protocol for ShyPal. For production, switch to binary/CBOR envelopes and native crypto.

- EphemeralBeaconId: human-readable 'EID...' in simulated mode
- IntroRequest / IntroReply: JSON packets used in simulated transport
- EncryptedMessage: { session_id, nonce, ciphertext, seq }
- SaveOffer / SaveConfirm: exchange friend_pub_key and create friend_token

Phase 1 uses JS-level crypto (tweetnacl) for prototyping only. Replace with libsodium/libsignal in Phase 2.
