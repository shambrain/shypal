export function encodeBase64(bytes){ return Buffer.from(bytes).toString('base64'); }
export function decodeBase64(s){ return new Uint8Array(Buffer.from(s,'base64')); }
