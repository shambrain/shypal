/**
 * Crypto wrapper (Phase 1) using TweetNaCl.js for X25519-like operations and secretbox for AES-like envelopes.
 * This is a JS-level prototype. Replace with native libsodium/libsignal for production.
 */

import nacl from 'tweetnacl';
import { encodeBase64, decodeBase64 } from './utils';

export function generateKeyPair(){
  const kp = nacl.box.keyPair();
  return { publicKey: encodeBase64(kp.publicKey), secretKey: encodeBase64(kp.secretKey) };
}

export function encryptMessage(sharedSecretBase64, plaintext){
  // sharedSecret: base64 32 bytes, use as key for secretbox
  const key = decodeBase64(sharedSecretBase64);
  const nonce = nacl.randomBytes(nacl.secretbox.nonceLength);
  const msgUint8 = new TextEncoder().encode(plaintext);
  const box = nacl.secretbox(msgUint8, nonce, key);
  return { nonce: encodeBase64(nonce), ciphertext: encodeBase64(box) };
}

export function decryptMessage(sharedSecretBase64, nonceBase64, ciphertextBase64){
  const key = decodeBase64(sharedSecretBase64);
  const nonce = decodeBase64(nonceBase64);
  const box = decodeBase64(ciphertextBase64);
  const msg = nacl.secretbox.open(box, nonce, key);
  if(!msg) throw new Error('Decryption failed');
  return new TextDecoder().decode(msg);
}
