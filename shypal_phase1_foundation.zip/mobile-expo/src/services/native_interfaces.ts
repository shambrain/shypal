/**
 * Native plugin TypeScript interfaces (Phase 1).
 * These are method signatures for platform-channel plugins that must be implemented natively later.
 *
 * Methods:
 * - startAdvertising(payload)
 * - stopAdvertising()
 * - startDiscovery()
 * - stopDiscovery()
 * - sendPayload(ephemeralId, bytes)
 * - onPayloadReceived -> event stream
 *
 * Implementation: create native plugins in ios_multipeer and android_nearby folders and wire to these names.
 */

export type NativeDiscovery = {
  startAdvertising: (info: Record<string,string>)=>Promise<string>;
  stopAdvertising: ()=>Promise<void>;
  startDiscovery: ()=>Promise<string>;
  stopDiscovery: ()=>Promise<void>;
  sendPayload: (peerId:string, bytes: Uint8Array)=>Promise<void>;
  addListener: (cb:(payload:any)=>void)=>void;
};


export const NativeBridge: NativeDiscovery = {
  // Phase 1 stubs - not implemented natively yet.
  async startAdvertising(info: Record<string,string>){ console.warn('startAdvertising: STUB'); return 'stub'; },
  async stopAdvertising(){ console.warn('stopAdvertising: STUB'); },
  async startDiscovery(){ console.warn('startDiscovery: STUB'); return 'stub'; },
  async stopDiscovery(){ console.warn('stopDiscovery: STUB'); },
  async sendPayload(peerId, bytes){ console.warn('sendPayload: STUB'); },
  addListener(cb){ console.warn('addListener: STUB'); }
};
