/**
 * SessionManager stub for Phase 1.
 * Uses simulated transport. Replace transport calls with native plugin calls later.
 */

import EventEmitter from 'events';
const emitter = new EventEmitter();

export class SessionManager {
  static forDevice(device){ return new SessionManager(device); }
  static async sendMessage(device, text){
    // simulate immediate echo back for demo
    setTimeout(()=>{
      emitter.emit('msg', { text, from: 'you' });
      emitter.emit('msg', { text: 'Echo: '+text, from: device.display });
    }, 300);
  }
  constructor(device){
    this.device = device;
  }
  subscribe(cb){
    const fn = (m)=>cb(m);
    emitter.on('msg', fn);
    return { unsubscribe: ()=> emitter.removeListener('msg', fn) };
  }
}
