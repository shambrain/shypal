/**
 * Simulated discovery service for Phase 1.
 * Provides a callback subscription that receives an array of nearby device stubs.
 */

import { EventEmitter } from 'events';

const emitter = new EventEmitter();

function makeDevice(i){
  return {
    eid: 'EID'+i,
    display: ['Coffee Person','Library Reader','Hoodie Guy'][i%3],
    distance: ['Near','Mid','Far'][i%3]
  };
}

let interval;
export function simulateDiscovery(callback){
  const listener = (devices)=>callback(devices);
  emitter.on('update', listener);
  if(!interval){
    let t=0;
    interval = setInterval(()=>{
      const devices = [makeDevice(t%3), makeDevice((t+1)%3)];
      emitter.emit('update', devices);
      t++;
    },2000);
  }
  return { unsubscribe: ()=> emitter.removeListener('update', listener) };
}
