import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, FlatList } from 'react-native';
import { SessionManager } from '../services/session_manager';

export default function ChatScreen({ route, navigation }) {
  const { device } = route.params;
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');

  useEffect(()=>{
    const sm = SessionManager.forDevice(device);
    const sub = sm.subscribe((m)=>setMessages((s)=>[...s,m]));
    return ()=>sub.unsubscribe();
  },[]);

  const send = async ()=>{
    if(!text) return;
    await SessionManager.sendMessage(device, text);
    setText('');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Chat with {device.display}</Text>
      <FlatList data={messages} keyExtractor={(m,i)=>String(i)} renderItem={({item})=>(
        <View style={styles.msg}><Text>{item.text}</Text></View>
      )} />
      <TextInput style={styles.input} value={text} onChangeText={setText} placeholder="Say hi" />
      <Button title="Send" onPress={send} />
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,padding:16},
  header:{fontSize:18,fontWeight:'600',marginBottom:8},
  input:{borderWidth:1,borderColor:'#ccc',padding:8,borderRadius:6,marginVertical:8},
  msg:{padding:8,backgroundColor:'#eef',borderRadius:6,marginBottom:6}
});
