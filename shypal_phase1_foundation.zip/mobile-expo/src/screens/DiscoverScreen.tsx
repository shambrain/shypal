import React, { useEffect, useState } from 'react';
import { View, Text, Button, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { simulateDiscovery } from '../services/simulated_discovery';

export default function DiscoverScreen({ navigation }) {
  const [nearby, setNearby] = useState([]);

  useEffect(() => {
    const sub = simulateDiscovery((devices) => setNearby(devices));
    return () => sub.unsubscribe();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Nearby</Text>
      <FlatList data={nearby} keyExtractor={(i) => i.eid} renderItem={({item})=>(
        <TouchableOpacity style={styles.item} onPress={()=>navigation.navigate('Chat',{ device: item })}>
          <Text>{item.display}</Text>
          <Text style={styles.sub}>{item.distance}</Text>
        </TouchableOpacity>
      )} />
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,padding:16},
  title:{fontSize:20,fontWeight:'600',marginBottom:8},
  item:{padding:12,borderRadius:8,backgroundColor:'#f2f2f8',marginBottom:8},
  sub:{color:'#666',fontSize:12}
});
