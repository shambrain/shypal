# ShyPal Phase 1 Foundation (Expo + JS Crypto + Simulated Discovery)

This Phase 1 scaffold provides a development foundation for ShyPal:
- Expo React Native app with Discover & Chat screens (simulated transport)
- TypeScript interfaces for native platform plugins (iOS Multipeer + Android Nearby)
- JS crypto wrapper using tweetnacl (prototype only)
- Node.js backend skeleton with endpoints for device register, friend upload, push, reports
- Docs: protocol, threat model, engineer handoff, device matrix
- CI stub (GitHub Actions)

**Important:** This scaffold is for development & prototyping. Native plugins and production crypto audit are required for public release.
