const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(bodyParser.json());

let devices = {};
let friends = {};

app.post('/devices/register', (req, res)=>{
  const { device_id, platform, pub_key } = req.body;
  devices[device_id] = { device_id, platform, pub_key, created_at: new Date().toISOString() };
  res.json({ status:'ok', server_device_id: device_id });
});

app.post('/friends/upload', (req, res)=>{
  const { device_id, friend_token, friend_pub_key } = req.body;
  friends[friend_token] = { owner: device_id, friend_pub_key, created_at: new Date().toISOString() };
  res.json({ status:'ok' });
});

app.post('/messages/push', (req, res)=>{
  // Accept ciphertext-only envelope for push routing
  res.json({ status:'queued' });
});

app.post('/reports', (req, res)=>{
  console.log('report', req.body);
  res.json({ status:'received' });
});

app.get('/health', (req,res)=>res.json({status:'ok'}));

const port = process.env.PORT || 8000;
app.listen(port, ()=> console.log('ShyPal backend listening on', port));
